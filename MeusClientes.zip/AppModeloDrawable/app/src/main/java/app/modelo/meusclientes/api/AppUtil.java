package app.modelo.meusclientes.api;

public class AppUtil {
    public static final String TAG = "teste";

}
