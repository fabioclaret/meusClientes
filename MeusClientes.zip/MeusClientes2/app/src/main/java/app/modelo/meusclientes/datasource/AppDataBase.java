package app.modelo.meusclientes.datasource;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import app.modelo.meusclientes.api.AppUtil;
import app.modelo.meusclientes.datamodel.ClienteDataModel;


public class AppDataBase extends SQLiteOpenHelper{
    public static final String DB_NAME = "MeusClientes.sqlite";
    public static final int VERSION    = 1;

    SQLiteDatabase db;
    public AppDataBase(Context context) {
        super(context, DB_NAME, null, VERSION);
        Log.i(AppUtil.TAG, "AppDataBase: Criando o Banco de Dados!");
        db = getWritableDatabase();

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(ClienteDataModel.criarTabela());
        ClienteDataModel ProdutoDataModel;
        Log.i(AppUtil.TAG, "AppDataBase: Tabela Cliente Criada!" + ClienteDataModel.criarTabela());
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    /**
     * Metodo para inserir registros na Tabela do banco de dados
     * @author Fabio Claret
     * @return  boolean
     */

    public boolean insert(String tabela, ContentValues dados){
        db = getWritableDatabase();
        boolean retorno = false;
        try {
            retorno= db.insert(tabela, null, dados) >0;
        }catch (Exception e){
            Log.i(AppUtil.TAG, "insert: " + e.getMessage());
        }
        return retorno;
    }

    /**
     * Metodo para deletar registros da tabela do banco de dados
     * @return boolean
     * @author Fabio Claret
     */
    public boolean deleteById(String tabela, int id){
        db = getWritableDatabase();
        boolean retorno = false;

        try {
            retorno  = db.delete(tabela,"id = ?",new String[]{String.valueOf(id)}) > 0;

        }catch (Exception e){
            Log.i(AppUtil.TAG, "deleteById: " + e.getMessage());
        }
        return retorno;
    }

    /**
     * Metodo para alterar registros da tabela do banco de dados
     * @return boolean
     * @author Fabio Claret
     */
    public boolean update(String tabela, ContentValues dados){
        db = getWritableDatabase();
        boolean retorno = false;

        try {
           Integer teste = (Integer) dados.get("id");


            retorno = db.update(tabela, dados, "id=?", new String[]{String.valueOf(dados.get("id"))  })>0;
        }catch (Exception e){
            Log.e(AppUtil.TAG, "update: " + e.getMessage() );
        }

        return retorno;
    }

}

