
package app.modelo.meusclientes.view;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import app.modelo.meusclientes.R;
import app.modelo.meusclientes.controller.ClienteController;
import app.modelo.meusclientes.model.Cliente;


public class AdicionarClienteFragment extends Fragment {
    TextView txtTitulo;
    EditText editNomeCompleto;
    EditText editTelefone;
    EditText editEmail;
    EditText editCep;
    EditText editLogradouro;
    EditText editNumero;
    EditText editBairro;
    EditText editCidade;
    EditText editEstado;
    CheckBox checkTermos;

    Cliente novoCliente;
    ClienteController controller;
    Button btnSalvar, btnCancelar;
    View view;

    public AdicionarClienteFragment() {
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view =  inflater.inflate(R.layout.fragment_adicionar_cliente, container, false);

        initFormulario();
        
        escutaEventodeBotao();
        
        return view;

    }

    private void escutaEventodeBotao() {
        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean isDadosOk = validaDados();

                if(isDadosOk) {
                    //popular o objeto
                    novoCliente.setNome(editNomeCompleto.getText().toString());
                    novoCliente.setTelefone(editTelefone.getText().toString());
                    novoCliente.setEmail(editEmail.getText().toString());
                    novoCliente.setCep(Integer.parseInt(editCep.getText().toString()));

                    novoCliente.setLogradouro(editLogradouro.getText().toString());
                    novoCliente.setNumero(editNumero.getText().toString());
                    novoCliente.setBairro(editBairro.getText().toString());
                    novoCliente.setCidade(editCidade.getText().toString());
                    novoCliente.setEstado(editEstado.getText().toString());
                    novoCliente.setTermosdeuso(checkTermos.isChecked());

                    controller.incluir(novoCliente);

                    limpaCampos();

                    Toast.makeText(getContext(), "Cliente Incluido com Sucesso!!", Toast.LENGTH_SHORT).show();
                }else{
                    //Notificar o usuario
                    //Toast
                    //Push Notification
                    //AlertDialog
                }
            }

            private boolean validaDados() {
                boolean isDadosOk = true;
                if(TextUtils.isEmpty(editNomeCompleto.getText())){
                    isDadosOk = false;
                    editNomeCompleto.setError("Digite o nome Completo");
                    editNomeCompleto.requestFocus();
                }
                if(TextUtils.isEmpty(editTelefone.getText())){
                    isDadosOk = false;
                    editTelefone.setError("Digite o numero de telefone");
                    editTelefone.requestFocus();
                }
                if(TextUtils.isEmpty(editEmail.getText())){
                    isDadosOk = false;
                    editEmail.setError("Digite o email");
                    editEmail.requestFocus();
                }
                if(TextUtils.isEmpty(editCep.getText())){
                    isDadosOk = false;
                    editCep.setError("Digite o nome Completo");
                    editCep.requestFocus();
                }
                if(TextUtils.isEmpty(editLogradouro.getText())){
                    isDadosOk = false;
                    editLogradouro.setError("Digite o nome Completo");
                    editLogradouro.requestFocus();
                }
                if(TextUtils.isEmpty(editNumero.getText())){
                    isDadosOk = false;
                    editNumero.setError("Digite o numero da casa");
                    editNumero.requestFocus();
                }
                if(TextUtils.isEmpty(editBairro.getText())){
                    isDadosOk = false;
                    editBairro.setError("Digite o bairro");
                    editBairro.requestFocus();
                }
                if(TextUtils.isEmpty(editCidade.getText())){
                    isDadosOk = false;
                    editCidade.setError("Digite a cidade");
                    editCidade.requestFocus();
                }
                if(TextUtils.isEmpty(editEstado.getText())){
                    isDadosOk = false;
                    editEstado.setError("Digite o estado");
                    editEstado.requestFocus();
                }
                return isDadosOk;
            }
        });

    }

    private void limpaCampos() {
        editBairro.setText("");
        editTelefone.setText("");
        editEmail.setText("");
        editCep.setText("");
        editCidade.setText("");
        editEstado.setText("");
        editLogradouro.setText("");
        editNomeCompleto.setText("");
        editNumero.setText("");

    }

    /**
     * Inicializar os componentes da tela de layout
     * para incluir um cliente
     * @author Fabio Claret
     */
    private void initFormulario() {
        txtTitulo         = view.findViewById(R.id.txtTitulo);
        txtTitulo.setText(R.string.novo_cliente);
        editBairro        = view.findViewById(R.id.editBairro);
        editTelefone      = view.findViewById(R.id.editTelefone);
        editEmail         = view.findViewById(R.id.editEmail);
        editCep           = view.findViewById(R.id.editCep);
        editCidade        = view.findViewById(R.id.editCidade);
        editEstado        = view.findViewById(R.id.editEstado);
        editLogradouro    = view.findViewById(R.id.editLogradouro);
        editNomeCompleto  = view.findViewById(R.id.editNomeCompleto);
        editNumero        = view.findViewById(R.id.editNumero);
        checkTermos       = view.findViewById(R.id.checkTermos);
        btnCancelar       = view.findViewById(R.id.btnCancelar);
        btnSalvar         = view.findViewById(R.id.btnSalvar);

        novoCliente = new Cliente();
        controller  = new ClienteController(getContext());
    }


}
