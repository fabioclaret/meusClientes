package app.modelo.meusclientes.datamodel;

public class ClienteDataModel {
    // Toda classe DataModel tem que ter essa estrutura:
    // 1 - Atributo com o nome da tabela.
    // 2 - Atributos um para um com os nomes dos campos.
    // 3 - Query para criar a tabela no banco de dados.
    // 4 - Metodo para gerar o script para criar a tabela.
    // 5 - Eventualmente outros metodos de consulta gerais.

    // 1
    public static final String TABELA = "clientes";

    // 2 - Aqui crio os atributos para a minha tabela no banco de dados
    public static final String ID            = "id";            //integer
    public static final String NOME          = "nome";          //text
    public static final String TELEFONE      = "telefone";      //text
    public static final String EMAIL         = "email";         //text
    public static final String CEP           = "cep";           //integer
    public static final String LOGRADOURO    = "logradouro";    //text
    public static final String NUMERO        = "numero";        //text
    public static final String BAIRRO        = "bairro";        //text
    public static final String CIDADE        = "cidade";        //text
    public static final String ESTADO        = "estado";        //text
    public static final String TERMOS_DE_USO = "termosDeUso";   //text

    // 3 - Aqui eu crio uma string em branco para colocar a query de criacao da tabela
    public static String queryCriarTabela = "";

    // 4
    public static String criarTabela(){
        queryCriarTabela += "CREATE TABLE " + TABELA + " (";
        queryCriarTabela += ID            + " integer primary key autoincrement, ";
        queryCriarTabela += NOME          + " text, ";
        queryCriarTabela += TELEFONE      + " text, ";
        queryCriarTabela += EMAIL         + " text, ";
        queryCriarTabela += CEP           + " integer, ";
        queryCriarTabela += LOGRADOURO    + " text, ";
        queryCriarTabela += NUMERO        + " text, ";
        queryCriarTabela += BAIRRO        + " text, ";
        queryCriarTabela += CIDADE        + " text, ";
        queryCriarTabela += ESTADO        + " text, ";
        queryCriarTabela += TERMOS_DE_USO + " integer ";

        queryCriarTabela += " )";

        return queryCriarTabela;
    }










}
